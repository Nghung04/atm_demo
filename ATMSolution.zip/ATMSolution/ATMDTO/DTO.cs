﻿using System;

namespace ATMDTO
{
    [Serializable]
    public class DTO
    {
        // Lenh gui tu client den server (VD: DANGNHAP, RUT, NAP, SODU, LICHSU)
        public string Lenh { get; set; }

        // Thong tin tai khoan
        public string TaiKhoan { get; set; }

        // Mat khau (chi dung khi dang nhap)
        public string MatKhau { get; set; }

        // So tien giao dich (neu co)
        public string SoTien { get; set; }
    }
}
