﻿using System;
using System.Text.Json;

namespace ATMDTO
{
    public static class JsonExtension
    {
        // Chuyen object sang JSON
        public static string ToJson(this object obj)
        {
            return JsonSerializer.Serialize(obj);
        }

        // Chuyen JSON sang object (kieu T)
        public static T FromJson<T>(this string json)
        {
            return JsonSerializer.Deserialize<T>(json);
        }
    }
}
