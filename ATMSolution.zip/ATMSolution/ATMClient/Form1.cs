﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using ATMDTO;
using ATMSecurity;

namespace ATMClient
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private string taiKhoanDangNhap = "";
        private StreamWriter sw;
        private StreamReader sr;

        public Form1()
        {
            InitializeComponent();
        }

        private void KetNoiServer()
        {
            try
            {
                client = new TcpClient("127.0.0.1", 9999);
                stream = client.GetStream();
                sw = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };
                sr = new StreamReader(stream, Encoding.UTF8);
                lblTrangThai.Text = "Trang thai: Da ket noi voi server";
            }
            catch
            {
                MessageBox.Show("Khong co tin hieu!");
            }
        }

        private void GuiTinNhan(DTO duLieu)
        {
            try
            {
                string json = duLieu.ToJson();
                string maHoa = MaHoa.Encrypt(json);
                sw.WriteLine(maHoa); // dùng StreamWriter toàn cục
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi gui du lieu: " + ex.Message);
            }
        }

        private string NhanTinNhan()
        {
            try
            {
                string maHoa = sr.ReadLine(); // dùng StreamReader toàn cục
                if (string.IsNullOrEmpty(maHoa))
                    return "Khong co du lieu tu server";

                string giaiMa = MaHoa.Decrypt(maHoa);
                return giaiMa;
            }
            catch (Exception ex)
            {
                return "Loi nhan du lieu tu server: " + ex.Message;
            }
        }


        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            if (client != null && client.Connected)
            {
                stream?.Close();
                sr?.Close();
                sw?.Close();
                client?.Close();
            }

            // Nếu đã đăng nhập tài khoản khác, đóng kết nối cũ
            if (client != null && client.Connected)
            {
                stream.Close();
                client.Close();
            }

            // Kết nối lại server
            KetNoiServer();

            DTO dto = new DTO
            {
                Lenh = "DANGNHAP",
                TaiKhoan = txtTaiKhoan.Text.Trim(),
                MatKhau = txtMatKhau.Text.Trim()
            };

            GuiTinNhan(dto);
            string ketQua = NhanTinNhan();

            // ✅ Ghi ra để kiểm tra phản hồi server
            txtKetQua.AppendText("[Server]: " + ketQua + Environment.NewLine);

            // ✅ So sánh linh hoạt hơn (không phân biệt hoa thường)
            if (ketQua.ToUpper().Contains("THANHCONG"))
            {
                taiKhoanDangNhap = txtTaiKhoan.Text.Trim();
                lblTrangThai.Text = $"Trang thai: Dang nhap thanh cong ({taiKhoanDangNhap})";
                txtKetQua.AppendText($"Dang nhap thanh cong - {ketQua}\r\n");
            }
            else
            {
                MessageBox.Show("Dang nhap that bai! Phan hoi tu server: " + ketQua);
            }

        }


        private void btnRutTien_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(taiKhoanDangNhap))
            {
                MessageBox.Show("Hay dang nhap truoc!");
                return;
            }

            txtKetQua.AppendText($"Gui lenh RUT voi tai khoan {taiKhoanDangNhap}, so tien {txtSoTien.Text}\r\n");

            DTO dto = new DTO
            {
                Lenh = "RUT",
                TaiKhoan = taiKhoanDangNhap,
                SoTien = txtSoTien.Text.Trim()
            };

            GuiTinNhan(dto);
            string kq = NhanTinNhan();
            txtKetQua.AppendText($"Phan hoi server: {kq}\r\n");
        }



        private void btnNapTien_Click(object sender, EventArgs e)
        {
            if (taiKhoanDangNhap == "") { MessageBox.Show("Hay dang nhap truoc!"); return; }

            DTO dto = new DTO
            {
                Lenh = "NAP",
                TaiKhoan = taiKhoanDangNhap,
                SoTien = txtSoTien.Text.Trim()
            };

            GuiTinNhan(dto);
            string kq = NhanTinNhan();
            txtKetQua.AppendText(kq + Environment.NewLine);
        }

        private void btnXemSoDu_Click(object sender, EventArgs e)
        {
            if (taiKhoanDangNhap == "") { MessageBox.Show("Hay dang nhap truoc!"); return; }

            DTO dto = new DTO
            {
                Lenh = "SODU",
                TaiKhoan = taiKhoanDangNhap
            };

            GuiTinNhan(dto);
            string kq = NhanTinNhan();
            txtKetQua.AppendText($"So du: {kq}" + Environment.NewLine);
        }

        private void btnLichSu_Click(object sender, EventArgs e)
        {
            if (taiKhoanDangNhap == "") { MessageBox.Show("Hay dang nhap truoc!"); return; }

            DTO dto = new DTO
            {

                Lenh = "LICHSU",
                TaiKhoan = taiKhoanDangNhap
            };

            GuiTinNhan(dto);
            string kq = NhanTinNhan();
            txtKetQua.AppendText($"Lich su:\n{kq}" + Environment.NewLine);
        }
        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            if (taiKhoanDangNhap == "")
            {
                MessageBox.Show("Chua dang nhap!");
                return;
            }

            try
            {
                DTO dto = new DTO
                {
                    Lenh = "DANGXUAT",
                    TaiKhoan = taiKhoanDangNhap
                };

                GuiTinNhan(dto);
                string kq = NhanTinNhan();

                if (kq.Contains("THANH CONG"))
                {
                    txtKetQua.AppendText($"Tai khoan {taiKhoanDangNhap} da dang xuat thanh cong.\n");
                    lblTrangThai.Text = "Trang thai: Da dang xuat";
                    taiKhoanDangNhap = "";

                    // Đóng kết nối để an toàn
                    stream?.Close();
                    client?.Close();
                    client = null;
                }
                else
                {
                    txtKetQua.AppendText($"Dang xuat that bai: {kq}\n");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi khi dang xuat: " + ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtKetQua_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
