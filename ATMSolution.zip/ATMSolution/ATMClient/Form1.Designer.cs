﻿namespace ATMClient
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtTaiKhoan;
        private System.Windows.Forms.TextBox txtMatKhau;
        private System.Windows.Forms.TextBox txtSoTien;
        private System.Windows.Forms.Button btnDangNhap;
        private System.Windows.Forms.Button btnRutTien;
        private System.Windows.Forms.Button btnNapTien;
        private System.Windows.Forms.Button btnXemSoDu;
        private System.Windows.Forms.Button btnLichSu;
        private System.Windows.Forms.RichTextBox txtKetQua;
        private System.Windows.Forms.Label lblTrangThai;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtTaiKhoan = new TextBox();
            txtMatKhau = new TextBox();
            txtSoTien = new TextBox();
            btnDangNhap = new Button();
            btnRutTien = new Button();
            btnNapTien = new Button();
            btnXemSoDu = new Button();
            btnLichSu = new Button();
            txtKetQua = new RichTextBox();
            lblTrangThai = new Label();
            btnDangXuat = new Button();
            SuspendLayout();
            // 
            // txtTaiKhoan
            // 
            txtTaiKhoan.Location = new Point(25, 20);
            txtTaiKhoan.Name = "txtTaiKhoan";
            txtTaiKhoan.PlaceholderText = "So tai khoan";
            txtTaiKhoan.Size = new Size(180, 23);
            txtTaiKhoan.TabIndex = 9;
            // 
            // txtMatKhau
            // 
            txtMatKhau.Location = new Point(220, 20);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.PasswordChar = '*';
            txtMatKhau.PlaceholderText = "Mat khau";
            txtMatKhau.Size = new Size(180, 23);
            txtMatKhau.TabIndex = 8;
            // 
            // txtSoTien
            // 
            txtSoTien.Location = new Point(25, 60);
            txtSoTien.Name = "txtSoTien";
            txtSoTien.PlaceholderText = "So tien";
            txtSoTien.Size = new Size(180, 23);
            txtSoTien.TabIndex = 7;
            // 
            // btnDangNhap
            // 
            btnDangNhap.Location = new Point(420, 20);
            btnDangNhap.Name = "btnDangNhap";
            btnDangNhap.Size = new Size(100, 25);
            btnDangNhap.TabIndex = 6;
            btnDangNhap.Text = "Dang nhap";
            btnDangNhap.UseVisualStyleBackColor = true;
            btnDangNhap.Click += btnDangNhap_Click;
            // 
            // btnRutTien
            // 
            btnRutTien.Location = new Point(220, 60);
            btnRutTien.Name = "btnRutTien";
            btnRutTien.Size = new Size(80, 25);
            btnRutTien.TabIndex = 5;
            btnRutTien.Text = "Rut tien";
            btnRutTien.UseVisualStyleBackColor = true;
            btnRutTien.Click += btnRutTien_Click;
            // 
            // btnNapTien
            // 
            btnNapTien.Location = new Point(310, 60);
            btnNapTien.Name = "btnNapTien";
            btnNapTien.Size = new Size(80, 25);
            btnNapTien.TabIndex = 4;
            btnNapTien.Text = "Nap tien";
            btnNapTien.UseVisualStyleBackColor = true;
            btnNapTien.Click += btnNapTien_Click;
            // 
            // btnXemSoDu
            // 
            btnXemSoDu.Location = new Point(400, 60);
            btnXemSoDu.Name = "btnXemSoDu";
            btnXemSoDu.Size = new Size(120, 25);
            btnXemSoDu.TabIndex = 3;
            btnXemSoDu.Text = "Xem so du";
            btnXemSoDu.UseVisualStyleBackColor = true;
            btnXemSoDu.Click += btnXemSoDu_Click;
            // 
            // btnLichSu
            // 
            btnLichSu.Location = new Point(530, 60);
            btnLichSu.Name = "btnLichSu";
            btnLichSu.Size = new Size(120, 25);
            btnLichSu.TabIndex = 2;
            btnLichSu.Text = "Lich su giao dich";
            btnLichSu.UseVisualStyleBackColor = true;
            btnLichSu.Click += btnLichSu_Click;
            // 
            // txtKetQua
            // 
            txtKetQua.Location = new Point(25, 100);
            txtKetQua.Name = "txtKetQua";
            txtKetQua.ReadOnly = true;
            txtKetQua.Size = new Size(625, 250);
            txtKetQua.TabIndex = 1;
            txtKetQua.Text = "";
            txtKetQua.TextChanged += txtKetQua_TextChanged;
            // 
            // lblTrangThai
            // 
            lblTrangThai.AutoSize = true;
            lblTrangThai.Location = new Point(25, 370);
            lblTrangThai.Name = "lblTrangThai";
            lblTrangThai.Size = new Size(81, 15);
            lblTrangThai.TabIndex = 0;
            lblTrangThai.Text = "Trang thai: ---";
            // 
            // btnDangXuat
            // 
            btnDangXuat.Location = new Point(550, 20);
            btnDangXuat.Name = "btnDangXuat";
            btnDangXuat.Size = new Size(100, 23);
            btnDangXuat.TabIndex = 10;
            btnDangXuat.Text = "Dang xuat";
            btnDangXuat.UseVisualStyleBackColor = true;
            btnDangXuat.Click += button1_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(680, 400);
            Controls.Add(btnDangXuat);
            Controls.Add(lblTrangThai);
            Controls.Add(txtKetQua);
            Controls.Add(btnLichSu);
            Controls.Add(btnXemSoDu);
            Controls.Add(btnNapTien);
            Controls.Add(btnRutTien);
            Controls.Add(btnDangNhap);
            Controls.Add(txtSoTien);
            Controls.Add(txtMatKhau);
            Controls.Add(txtTaiKhoan);
            Name = "Form1";
            Text = "ATM Client";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }
        private Button btnDangXuat;
    }
}
