﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

using System.IO;

namespace ATMDatabase
{
    public static class Database
    {
        private static readonly string connMaster = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True";
        private static readonly string connStr = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ATMDB;Integrated Security=True";

        static Database()
        {
            TaoDatabaseNeuChuaCo();
            TaoBangNeuChuaCo();
        }

        // ✅ Tự động tạo database nếu chưa có
        private static void TaoDatabaseNeuChuaCo()
        {
            using SqlConnection conn = new SqlConnection(connMaster);
            conn.Open();
            string checkDb = "IF DB_ID('ATMDB') IS NULL CREATE DATABASE ATMDB";
            new SqlCommand(checkDb, conn).ExecuteNonQuery();
        }

        // ✅ Tạo các bảng cần thiết
        private static void TaoBangNeuChuaCo()
        {
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string taoTaiKhoan = @"
            IF OBJECT_ID('TaiKhoan', 'U') IS NULL
            CREATE TABLE TaiKhoan(
                SoTaiKhoan NVARCHAR(50) PRIMARY KEY,
                MatKhau NVARCHAR(50),
                SoDu DECIMAL(18,2)
            )";

            string taoLichSu = @"
            IF OBJECT_ID('LichSuGiaoDich', 'U') IS NULL
            CREATE TABLE LichSuGiaoDich(
                Id INT IDENTITY(1,1) PRIMARY KEY,
                SoTaiKhoan NVARCHAR(50),
                LoaiGiaoDich NVARCHAR(50),
                SoTien DECIMAL(18,2),
                ThoiGian DATETIME DEFAULT GETDATE()
            )";

            new SqlCommand(taoTaiKhoan, conn).ExecuteNonQuery();
            new SqlCommand(taoLichSu, conn).ExecuteNonQuery();

            // ✅ Thêm dữ liệu mẫu nếu trống
            string check = "SELECT COUNT(*) FROM TaiKhoan";
            int count = Convert.ToInt32(new SqlCommand(check, conn).ExecuteScalar());
            if (count == 0)
            {
                string insert = @"
                INSERT INTO TaiKhoan (SoTaiKhoan, MatKhau, SoDu) VALUES
                ('1001', '123', 5000000),
                ('1002', '456', 2000000)";
                new SqlCommand(insert, conn).ExecuteNonQuery();
            }
        }

        // ✅ Xử lý đăng nhập
        public static bool KiemTraDangNhap(string stk, string mk)
        {
            using SqlConnection conn = new(connStr);
            conn.Open();
            string sql = "SELECT COUNT(*) FROM TaiKhoan WHERE SoTaiKhoan=@stk AND MatKhau=@mk";
            using SqlCommand cmd = new(sql, conn);
            cmd.Parameters.AddWithValue("@stk", stk);
            cmd.Parameters.AddWithValue("@mk", mk);
            int count = (int)cmd.ExecuteScalar();
            return count > 0;
        }

        // ✅ Rút tiền
        public static string RutTien(string stk, decimal soTien)
        {
            using SqlConnection conn = new(connStr);
            conn.Open();

            SqlCommand check = new("SELECT SoDu FROM TaiKhoan WHERE SoTaiKhoan=@stk", conn);
            check.Parameters.AddWithValue("@stk", stk);
            object result = check.ExecuteScalar();

            if (result == null) return "TAI KHOAN KHONG TON TAI";

            decimal soDu = (decimal)result;
            if (soDu < soTien)
                return "KHONG DU SO DU";

            SqlCommand rut = new("UPDATE TaiKhoan SET SoDu = SoDu - @tien WHERE SoTaiKhoan=@stk", conn);
            rut.Parameters.AddWithValue("@stk", stk);
            rut.Parameters.AddWithValue("@tien", soTien);
            rut.ExecuteNonQuery();

            GhiLichSu(conn, stk, "Rut tien", soTien);
            return "RUT THANH CONG";
        }

        // ✅ Nạp tiền
        public static string NapTien(string stk, decimal soTien)
        {
            using SqlConnection conn = new(connStr);
            conn.Open();

            SqlCommand nap = new("UPDATE TaiKhoan SET SoDu = SoDu + @tien WHERE SoTaiKhoan=@stk", conn);
            nap.Parameters.AddWithValue("@stk", stk);
            nap.Parameters.AddWithValue("@tien", soTien);
            int rows = nap.ExecuteNonQuery();

            if (rows == 0) return "TAI KHOAN KHONG TON TAI";

            GhiLichSu(conn, stk, "Nap tien", soTien);
            return "NAP THANH CONG";
        }

        // ✅ Xem lịch sử giao dịch
        public static DataTable XemLichSu(string stk)
        {
            using SqlConnection conn = new(connStr);
            conn.Open();
            SqlCommand cmd = new("SELECT LoaiGiaoDich, SoTien, ThoiGian FROM LichSuGiaoDich WHERE SoTaiKhoan=@stk ORDER BY ThoiGian DESC", conn);
            cmd.Parameters.AddWithValue("@stk", stk);
            SqlDataAdapter da = new(cmd);
            DataTable dt = new();
            da.Fill(dt);
            return dt;
        }

        // ✅ Ghi lịch sử giao dịch
        private static void GhiLichSu(SqlConnection conn, string stk, string loai, decimal tien)
        {
            SqlCommand log = new("INSERT INTO LichSuGiaoDich (SoTaiKhoan, LoaiGiaoDich, SoTien) VALUES (@stk,@loai,@tien)", conn);
            log.Parameters.AddWithValue("@stk", stk);
            log.Parameters.AddWithValue("@loai", loai);
            log.Parameters.AddWithValue("@tien", tien);
            log.ExecuteNonQuery();
        }
        // ✅ Lấy lịch sử giao dịch dưới dạng chuỗi để gửi cho client
        public static string LayLichSuGiaoDich(string stk)
        {
            DataTable dt = XemLichSu(stk);
            if (dt.Rows.Count == 0)
                return "Chua co giao dich nao";

            StringWriter sw = new();
            foreach (DataRow row in dt.Rows)
            {
                string loai = row["LoaiGiaoDich"].ToString();
                decimal soTien = (decimal)row["SoTien"];
                DateTime thoiGian = (DateTime)row["ThoiGian"];
                sw.WriteLine($"{thoiGian:dd/MM/yyyy HH:mm:ss} - {loai}: {soTien:N0} VND");
            }
            return sw.ToString();
        }

        // ✅ Lấy số dư hiện tại của tài khoản
        public static decimal LaySoDu(string stk)
        {
            using SqlConnection conn = new(connStr);
            conn.Open();
            SqlCommand cmd = new("SELECT SoDu FROM TaiKhoan WHERE SoTaiKhoan=@stk", conn);
            cmd.Parameters.AddWithValue("@stk", stk);
            object result = cmd.ExecuteScalar();
            return result == null ? 0 : (decimal)result;
        }

    }
}
