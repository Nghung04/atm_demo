﻿using ATMDatabase;
using ATMDTO;
using ATMSecurity;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ATMServer
{
    public partial class Form1 : Form
    {
        private void GhiLog(string noiDung)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "server_log.txt");
            string line = $"[{DateTime.Now:dd/MM/yyyy HH:mm:ss}] {noiDung}";
            File.AppendAllText(path, line + Environment.NewLine);
        }

        private void btnXemOnline_Click(object sender, EventArgs e)
        {
            txtTrangThai.AppendText($"=== Danh sách client đang online ({dsClientOnline.Count}) ===\r\n");
            foreach (var c in dsClientOnline.Keys)
                txtTrangThai.AppendText($"- {c}\r\n");
        }

        TcpListener server;
        Thread threadLangNghe;
        ConcurrentDictionary<string, TcpClient> dsClientOnline = new ConcurrentDictionary<string, TcpClient>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnBatDau_Click(object sender, EventArgs e)
        {
            try
            {
                server = new TcpListener(IPAddress.Any, 9999);
                server.Start();
                threadLangNghe = new Thread(LangNghe);
                threadLangNghe.Start();
                txtTrangThai.AppendText("Server da khoi dong tren cong 9999...\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi: " + ex.Message);
            }
        }

        void LangNghe()
        {
            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                new Thread(() => XuLyClient(client)).Start();
            }
        }

        void XuLyClient(TcpClient client)
        {
            string stk = "";
            try
            {
                using NetworkStream ns = client.GetStream();
                using StreamReader sr = new StreamReader(ns, Encoding.UTF8);
                using StreamWriter sw = new StreamWriter(ns, Encoding.UTF8) { AutoFlush = true };

                while (client.Connected)
                {
                    string yeuCauMaHoa = sr.ReadLine();
                    if (string.IsNullOrEmpty(yeuCauMaHoa))
                        break;

                    string yeuCau = MaHoa.Decrypt(yeuCauMaHoa);
                    

                    // ✅ Parse JSON sang DTO
                    DTO duLieu = yeuCau.FromJson<DTO>();
                    string lenh = duLieu.Lenh;
                    stk = duLieu.TaiKhoan;
                    string mk = duLieu.MatKhau;
                    string soTienStr = duLieu.SoTien ?? "0";

                    string phanHoi = "";

                    switch (lenh)
                    {
                        case "DANGNHAP":
                            {
                                bool hopLe = Database.KiemTraDangNhap(stk, mk);
                                if (hopLe)
                                {
                                    dsClientOnline[stk] = client;
                                    decimal soDu = Database.LaySoDu(stk);
                                    phanHoi = $"THANHCONG|{soDu}";
                                    Invoke((MethodInvoker)(() =>
                                        txtTrangThai.AppendText($"[{DateTime.Now:T}] Client {stk} đăng nhập thành công (Số dư: {soDu:N0} VND)\r\n")));
                                }
                                else
                                {
                                    phanHoi = "THATBAI";
                                    Invoke((MethodInvoker)(() =>
                                        txtTrangThai.AppendText($"[{DateTime.Now:T}] Client {stk} đăng nhập thất bại\r\n")));
                                }
                                break;
                            }

                        case "DANGXUAT":
                            {
                                if (dsClientOnline.ContainsKey(stk))
                                {
                                    dsClientOnline.TryRemove(stk, out _);
                                    phanHoi = "DANGXUAT_THANHCONG";
                                    Invoke((MethodInvoker)(() =>
                                        txtTrangThai.AppendText($"[{DateTime.Now:T}] Client {stk} đã đăng xuất\r\n")));
                                }
                                else
                                    phanHoi = "DANGXUAT_THATBAI";
                                break;
                            }
                        case "SODU":
                            {
                                decimal soDu = Database.LaySoDu(stk);
                                phanHoi = soDu.ToString(); // ✅ chỉ gửi số dư thôi
                                GhiLog($"{stk} xem số dư: {soDu:N0} VND");
                                break;
                            }
                        case "LICHSU":
                            {
                                string lichSu = Database.LayLichSuGiaoDich(stk);
                                phanHoi = $"LICHSU|{lichSu}";
                                GhiLog($"{stk} xem lịch sử giao dịch");
                                break;
                            }

                        case "RUT":
                        case "RUTTIEN":
                            phanHoi = Database.RutTien(stk, decimal.Parse(soTienStr));
                            break;

                        case "NAP":
                        case "NAPTIEN":
                            phanHoi = Database.NapTien(stk, decimal.Parse(soTienStr));
                            break;

                        default:
                            phanHoi = "LENH KHONG HOP LE";
                            break;
                    }

                    // 🔹 Gửi phản hồi lại client (mã hóa)
                    string phanHoiMaHoa = MaHoa.Encrypt(phanHoi);
                    sw.WriteLine(phanHoiMaHoa);
                }
            }
            catch (Exception ex)
            {
                Invoke((MethodInvoker)(() =>
                    txtTrangThai.AppendText($"[Lỗi xử lý client {stk}] {ex.Message}\r\n")));
            }
            finally
            {
                if (!string.IsNullOrEmpty(stk))
                    dsClientOnline.TryRemove(stk, out _);
                client.Close();
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtTrangThai_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
