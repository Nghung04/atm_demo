﻿namespace ATMServer
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnBatDau;
        private System.Windows.Forms.TextBox txtTrangThai;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnBatDau = new Button();
            txtTrangThai = new TextBox();
            btnXemOnline = new Button();
            SuspendLayout();
            // 
            // btnBatDau
            // 
            btnBatDau.Location = new Point(12, 12);
            btnBatDau.Name = "btnBatDau";
            btnBatDau.Size = new Size(120, 40);
            btnBatDau.TabIndex = 0;
            btnBatDau.Text = "Bat dau Server";
            btnBatDau.UseVisualStyleBackColor = true;
            btnBatDau.Click += btnBatDau_Click;
            // 
            // txtTrangThai
            // 
            txtTrangThai.Location = new Point(12, 70);
            txtTrangThai.Multiline = true;
            txtTrangThai.Name = "txtTrangThai";
            txtTrangThai.ScrollBars = ScrollBars.Vertical;
            txtTrangThai.Size = new Size(500, 250);
            txtTrangThai.TabIndex = 1;
            txtTrangThai.TextChanged += txtTrangThai_TextChanged;
            // 
            // btnXemOnline
            // 
            btnXemOnline.Location = new Point(265, 17);
            btnXemOnline.Name = "btnXemOnline";
            btnXemOnline.Size = new Size(247, 31);
            btnXemOnline.TabIndex = 2;
            btnXemOnline.Text = "Danh sach Online";
            btnXemOnline.UseVisualStyleBackColor = true;
            btnXemOnline.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(524, 341);
            Controls.Add(btnXemOnline);
            Controls.Add(txtTrangThai);
            Controls.Add(btnBatDau);
            Name = "Form1";
            Text = "May Chu ATM";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }
        private Button btnXemOnline;
    }
}
