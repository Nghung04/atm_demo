﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ATMSecurity
{
    public static class MaHoa
    {
        private static readonly byte[] key = Encoding.UTF8.GetBytes("1234567890123456");
        private static readonly byte[] iv = Encoding.UTF8.GetBytes("6543210987654321");

        // Mã hóa
        public static string Encrypt(string plainText)
        {
            using Aes aes = Aes.Create();
            aes.Key = key;
            aes.IV = iv;

            using MemoryStream ms = new();
            using CryptoStream cs = new(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
            using (StreamWriter sw = new(cs))
            {
                sw.Write(plainText);
            }
            return Convert.ToBase64String(ms.ToArray());
        }

        // Giải mã
        public static string Decrypt(string cipherText)
        {
            using Aes aes = Aes.Create();
            aes.Key = key;
            aes.IV = iv;

            byte[] buffer = Convert.FromBase64String(cipherText);
            using MemoryStream ms = new(buffer);
            using CryptoStream cs = new(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
            using StreamReader sr = new(cs);
            return sr.ReadToEnd();
        }
    }
}
